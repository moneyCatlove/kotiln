package com.example.smartring.ui.theme.setting

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun HealthMonitoringSettingsScreen(navController: NavController) {
    Text(text = "건강 모니터링 설정 화면입니다.")
}
