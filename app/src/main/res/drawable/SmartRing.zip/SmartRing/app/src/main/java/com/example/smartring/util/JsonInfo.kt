package com.example.smartring.util

import org.json.JSONObject
import java.io.Serializable

class JsonInfo : Serializable {
    var cmdKey: String? = null
    var jsonObject: JSONObject? = null
}
