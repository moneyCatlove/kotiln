package com.example.smartring.ui.theme.setting

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun FirmwareUpgradeScreen(navController: NavController) {
    Text(text = "펌웨어 업그레이드 화면입니다.")
}
