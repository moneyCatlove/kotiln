package com.example.smartring.ui.theme.setting

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun SystemSettingsScreen(navController: NavController) {
    Text(text = "시스템 설정 화면입니다.")
}
