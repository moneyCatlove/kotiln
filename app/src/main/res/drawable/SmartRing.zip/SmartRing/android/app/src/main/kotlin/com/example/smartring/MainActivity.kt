package com.example.smartring

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
